import { useState } from "react";
import { Link, NavLink } from "react-router-dom";
import Button from "../common/Button";

const links = [
  { to: "/", label: "Dashboard" },
  { to: "/courses", label: "Courses" },
  { to: "/my-courses", label: "My Courses" },
];

function Navbar({ user, onLogout }) {
  const [menuOpen, setMenuOpen] = useState(false);

  function linkClass({ isActive }) {
    return `block rounded-lg px-3 py-2 text-sm font-medium ${
      isActive ? "bg-indigo-50 text-indigo-700" : "text-gray-600 hover:bg-gray-100"
    }`;
  }

  return (
    <header className="sticky top-0 z-30 border-b border-gray-200 bg-white">
      <div className="mx-auto flex max-w-6xl items-center justify-between px-4 py-3">
        <Link to="/" className="text-lg font-bold text-indigo-600">
          LMS Belajar
        </Link>

        {/* Menu desktop */}
        <nav className="hidden items-center gap-1 md:flex">
          {links.map((link) => (
            <NavLink key={link.to} to={link.to} end={link.to === "/"} className={linkClass}>
              {link.label}
            </NavLink>
          ))}
        </nav>

        <div className="hidden items-center gap-3 md:flex">
          <span className="text-sm text-gray-600">{user.name}</span>
          <Button variant="secondary" onClick={onLogout}>
            Logout
          </Button>
        </div>

        {/* Tombol menu mobile */}
        <button
          className="rounded-lg border border-gray-300 px-3 py-1.5 text-sm md:hidden"
          onClick={() => setMenuOpen(!menuOpen)}
          aria-label="Buka menu"
        >
          {menuOpen ? "✕" : "☰"}
        </button>
      </div>

      {/* Menu mobile */}
      {menuOpen && (
        <nav className="space-y-1 border-t border-gray-200 px-4 py-3 md:hidden">
          {links.map((link) => (
            <NavLink
              key={link.to}
              to={link.to}
              end={link.to === "/"}
              className={linkClass}
              onClick={() => setMenuOpen(false)}
            >
              {link.label}
            </NavLink>
          ))}
          <p className="px-3 pt-2 text-sm text-gray-500">Masuk sebagai {user.name}</p>
          <Button variant="secondary" className="w-full" onClick={onLogout}>
            Logout
          </Button>
        </nav>
      )}
    </header>
  );
}

export default Navbar;
