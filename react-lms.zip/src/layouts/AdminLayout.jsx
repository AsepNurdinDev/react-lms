import { useState } from "react";
import { Navigate, Outlet, useNavigate } from "react-router-dom";
import AdminSidebar from "../components/admin/AdminSidebar";
import AdminHeader from "../components/admin/AdminHeader";
import useLocalStorage from "../hooks/useLocalStorage";

function AdminLayout() {
  const [currentUser, setCurrentUser] = useLocalStorage("lms_current_admin", null);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const navigate = useNavigate();

  function handleLogout() {
    setCurrentUser(null);
    navigate("/admin/login");
  }


  // Hanya admin yang boleh membuka halaman admin.
  if (!currentUser) return <Navigate to="/admin/login" replace />;
  if (currentUser.role !== "admin") return <Navigate to="/" replace />;

  return (
    <div className="min-h-screen bg-gray-50 text-gray-800">
      <AdminSidebar open={sidebarOpen} onClose={() => setSidebarOpen(false)} />

      <div className="lg:pl-64">
        <AdminHeader user={currentUser} onMenuClick={() => setSidebarOpen(true)} onLogout={handleLogout} />
        <main className="p-4 sm:p-6">
          <Outlet />
        </main>
      </div>
    </div>
  );
}

export default AdminLayout;
