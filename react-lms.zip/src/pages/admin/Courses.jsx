import { useState } from "react";
import DataTable from "../../components/admin/DataTable";
import Badge from "../../components/common/Badge";
import Button from "../../components/common/Button";
import Input from "../../components/common/Input";
import Modal from "../../components/common/Modal";
import useLocalStorage from "../../hooks/useLocalStorage";
import formatCurrency from "../../utils/formatCurrency";
import { courses as initialCourses, categories } from "../../data/courses";

const levels = ["Beginner", "Intermediate", "Advanced"];

const emptyForm = {
  title: "",
  instructor: "",
  category: categories[0],
  level: levels[0],
  price: "",
  duration: "",
  description: "",
};

function Courses() {
  const [courses, setCourses] = useLocalStorage("lms_courses", initialCourses);
  const [search, setSearch] = useState("");
  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState(null); // null = mode tambah
  const [form, setForm] = useState(emptyForm);
  const [errors, setErrors] = useState({});
  const [courseToDelete, setCourseToDelete] = useState(null);

  const filteredCourses = courses.filter((course) =>
    `${course.title} ${course.instructor} ${course.category}`.toLowerCase().includes(search.toLowerCase())
  );

  // ----- Tambah & Edit -----
  function openAddForm() {
    setEditingId(null);
    setForm(emptyForm);
    setErrors({});
    setShowForm(true);
  }

  function openEditForm(course) {
    setEditingId(course.id);
    setForm({
      title: course.title,
      instructor: course.instructor,
      category: course.category,
      level: course.level,
      price: String(course.price),
      duration: course.duration,
      description: course.description,
    });
    setErrors({});
    setShowForm(true);
  }

  function handleChange(event) {
    setForm({ ...form, [event.target.name]: event.target.value });
  }

  function validate() {
    const newErrors = {};
    if (form.title.trim() === "") newErrors.title = "Judul wajib diisi.";
    if (form.instructor.trim() === "") newErrors.instructor = "Instructor wajib diisi.";
    if (form.price === "" || Number(form.price) <= 0) newErrors.price = "Harga harus lebih dari 0.";
    if (form.duration.trim() === "") newErrors.duration = "Durasi wajib diisi.";
    if (form.description.trim() === "") newErrors.description = "Deskripsi wajib diisi.";
    return newErrors;
  }

  function handleSubmit(event) {
    event.preventDefault();

    const newErrors = validate();
    setErrors(newErrors);
    if (Object.keys(newErrors).length > 0) return;

    const courseData = {
      title: form.title.trim(),
      instructor: form.instructor.trim(),
      category: form.category,
      level: form.level,
      price: Number(form.price),
      duration: form.duration.trim(),
      description: form.description.trim(),
    };

    if (editingId === null) {
      // CREATE
      const newCourse = {
        id: Math.max(0, ...courses.map((course) => course.id)) + 1,
        ...courseData,
        students: 0,
        image: "/images/courses/default.svg",
        lessons: [{ id: 1, title: "Pengantar", content: "Materi pengantar untuk course ini." }],
      };
      setCourses([...courses, newCourse]);
    } else {
      // UPDATE
      setCourses(courses.map((course) => (course.id === editingId ? { ...course, ...courseData } : course)));
    }

    setShowForm(false);
  }

  // ----- Hapus -----
  function handleDelete() {
    setCourses(courses.filter((course) => course.id !== courseToDelete.id));
    setCourseToDelete(null);
  }

  const columns = [
    { key: "title", label: "Judul" },
    { key: "category", label: "Kategori", render: (course) => <Badge color="indigo">{course.category}</Badge> },
    { key: "level", label: "Level" },
    { key: "price", label: "Harga", render: (course) => formatCurrency(course.price) },
    { key: "students", label: "Siswa" },
    {
      key: "actions",
      label: "Aksi",
      render: (course) => (
        <div className="flex gap-2">
          <Button variant="secondary" onClick={() => openEditForm(course)}>
            Edit
          </Button>
          <Button variant="danger" onClick={() => setCourseToDelete(course)}>
            Hapus
          </Button>
        </div>
      ),
    },
  ];

  return (
    <div>
      <div className="mb-4 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <h1 className="text-2xl font-bold text-gray-900">Courses</h1>
        <Button onClick={openAddForm}>+ Tambah Course</Button>
      </div>

      <div className="max-w-sm">
        <Input
          label="Cari course"
          placeholder="Judul, instructor, atau kategori"
          value={search}
          onChange={(event) => setSearch(event.target.value)}
        />
      </div>

      <DataTable columns={columns} data={filteredCourses} emptyMessage="Tidak ada course yang ditemukan." />

      {/* Modal form tambah/edit */}
      <Modal open={showForm} title={editingId === null ? "Tambah Course" : "Edit Course"} onClose={() => setShowForm(false)}>
        <form onSubmit={handleSubmit} noValidate>
          <Input label="Judul" name="title" value={form.title} onChange={handleChange} error={errors.title} />
          <Input
            label="Instructor"
            name="instructor"
            value={form.instructor}
            onChange={handleChange}
            error={errors.instructor}
          />

          <div className="grid gap-x-4 sm:grid-cols-2">
            <Input as="select" label="Kategori" name="category" value={form.category} onChange={handleChange}>
              {categories.map((item) => (
                <option key={item} value={item}>
                  {item}
                </option>
              ))}
            </Input>
            <Input as="select" label="Level" name="level" value={form.level} onChange={handleChange}>
              {levels.map((item) => (
                <option key={item} value={item}>
                  {item}
                </option>
              ))}
            </Input>
            <Input
              label="Harga (Rp)"
              name="price"
              type="number"
              min="0"
              value={form.price}
              onChange={handleChange}
              error={errors.price}
            />
            <Input
              label="Durasi"
              name="duration"
              placeholder="Contoh: 8 Jam"
              value={form.duration}
              onChange={handleChange}
              error={errors.duration}
            />
          </div>

          <Input
            as="textarea"
            rows="3"
            label="Deskripsi"
            name="description"
            value={form.description}
            onChange={handleChange}
            error={errors.description}
          />

          <div className="flex justify-end gap-2">
            <Button variant="secondary" onClick={() => setShowForm(false)}>
              Batal
            </Button>
            <Button type="submit">Simpan</Button>
          </div>
        </form>
      </Modal>

      {/* Modal konfirmasi hapus */}
      <Modal open={courseToDelete !== null} title="Hapus Course" onClose={() => setCourseToDelete(null)}>
        <p className="text-sm text-gray-600">
          Yakin ingin menghapus course <strong>{courseToDelete?.title}</strong>?
        </p>
        <div className="mt-6 flex justify-end gap-2">
          <Button variant="secondary" onClick={() => setCourseToDelete(null)}>
            Batal
          </Button>
          <Button variant="danger" onClick={handleDelete}>
            Hapus
          </Button>
        </div>
      </Modal>
    </div>
  );
}

export default Courses;
